        <div class="index-Public">
            <div class="title-line mb-30 mil-up">
                <h2 class="one-line">标签云</h2>
                <div class="mil-line"></div>
                <div class="mil-h2 mil-number one-line">01</div>
            </div>
            <div class="widget_tag_cloud ">
                <?php Typecho_Widget::widget('Widget_Metas_Tag_Cloud','ignoreZeroCount=1&limit=150')->to($tags); ?>
                    <?php if($tags->have()): ?>
                        <?php while ($tags->next()): ?>
                        <span id="tag-clould-color">
                            <a  href="<?php $tags->permalink();?>" class="mil-link mil-hover-link mil-text-link" target="_blank">
                            <?php $tags->name(); ?></a>
                        </span>
                       <?php endwhile; ?>
                <?php endif; ?>
            </div>
            <div class="title-line mb-30 mil-up">
                <h2 class="one-line">文章归档</h2>
                <div class="mil-line"></div>
                <div class="mil-h2 mil-number one-line">02</div>
            </div>
            <div class="widget_Contents_Post">
                <?php 
			$this->widget('Widget_Contents_Post_Recent', 'pageSize=10000')->to($archives);   
			$year=0; $mon=0; $i=0; $j=0;   
			$output = '';   
			while($archives->next()):   
				$year_tmp = date('Y',$archives->created);   
				$mon_tmp = date('m',$archives->created);   
				$y=$year; $m=$mon;   
				if ($mon != $mon_tmp && $mon > 0) $output .= '</article>';   
				if ($year != $year_tmp && $year > 0) $output .= '</div>';   
				if ($year != $year_tmp) {   
					$year = $year_tmp;   
					$output .= '<section class="py-3">
									<h4 class="gdn">'. $year .' 年</h4>
									<div class="timeline">';    
				}   
				 if ($archives->fields->article_type == "photos") { //<!-- 相册样式 -->
					$output .= '			
					<article class="timeline__item">
						<span class="timeline__period">'.date('m-d',$archives->created).'</span>
						<a href="'.$archives->permalink .'" class="mil-link mil-hover-link mil-text-link"><h5 class="title title--h5 timeline__title text-sm">'. $archives->title .'<i class="ri-image-line pl-2" data-toggle="tooltip" data-placement="bottom" title="相册"></i></h5></a>
					</article>'; //输出文章日期和标题  
				 } elseif ($archives->fields->article_type == "books") { //<!-- 书单样式 -->
					$output .= '			
					<article class="timeline__item">
						<span class="timeline__period">'.date('m-d',$archives->created).'</span>
						<a href="'.$archives->permalink .'" class="mil-link mil-hover-link mil-text-link"><h5 class="title title--h5 timeline__title text-sm">'. $archives->title .'<i class="ri-book-2-line pl-2" data-toggle="tooltip" data-placement="bottom" title="书单"></i></h5></a>
					</article>'; //输出文章日期和标题  
				 } elseif ($archives->fields->article_type == "movies") { //<!-- 影单样式 -->
					$output .= '			
					<article class="timeline__item">
						<span class="timeline__period">'.date('m-d',$archives->created).'</span>
						<a href="'.$archives->permalink .'" class="mil-link mil-hover-link mil-text-link"><h5 class="title title--h5 timeline__title text-sm">'. $archives->title .'<i class="ri-movie-2-line pl-2" data-toggle="tooltip" data-placement="bottom" title="影单"></i></h5></a>
					</article>'; //输出文章日期和标题  
				 } else {//<!-- 默认样式（文章） -->
					$output .= '			
					<article class="timeline__item">
						<span class="timeline__period">'.date('m-d',$archives->created).'</span>
						<a href="'.$archives->permalink .'" class="mil-link mil-hover-link mil-text-link"><h5 class="title title--h5 timeline__title text-sm">'. $archives->title .'</h5></a>
					</article>'; //输出文章日期和标题  
				 }
				 
			endwhile;   
			$output .= '
			<article class="timeline__item pb-0">
				<h5 class="title timeline__title text-sm timeline__title_end">开始</h5>
			</article>
			</div></section>';
			echo $output;
		?>

            </div>
        </div>