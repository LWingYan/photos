    <nav class="header-navbar">
        <ul class="navigation-list category-list">
            <li>
                <a href="<?php $this->options->siteUrl(); ?>">
                    <i class="ri-home-4-line ri-2x"></i>
                    <span>首页</span>
                </a>
            </li>
            
            <?php
            if ($this->options->navigationItems) {
                $navigationItems = explode("\n", $this->options->navigationItems);
            ?>
            <?php foreach ($navigationItems as $item): ?>
                <?php
                $item = explode('|', $item);
                if (count($item) == 3) {
                    list($iconUrl, $linkUrl, $linkName) = $item;
                ?>
                    <li>
                        <a href="<?php $this->options->index(); ?>category/<?php echo htmlspecialchars($linkUrl); ?>">
                        <?php echo $iconUrl; ?>
                            <span><?php echo htmlspecialchars($linkName); ?></span>
                        </a>
                    </li>
                <?php } ?>
            <?php endforeach; ?>
            <?php
            }
            ?>
        </ul>
    </nav>