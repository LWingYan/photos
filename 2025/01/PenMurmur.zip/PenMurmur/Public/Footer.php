<footer class="content-footer">
    <div class="footer-copy">
        <p>&copy; <?php echo date('Y'); ?>.All rights reserved.</p>
        <p>Design by: <a href="//ouyu.me/" class="mil-link mil-hover-link mil-text-link">Lin Yi</a></p>
    </div>
</footer>