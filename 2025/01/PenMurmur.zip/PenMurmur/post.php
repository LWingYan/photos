<?php
if (!defined('__TYPECHO_ROOT_DIR__')) exit;
$this->need('Public/Include.php');
?>
<div class="main-wrapper">
    <!--侧栏导航-->
    <?php $this->need('Public/Header.php');?>
    <!--主体-->
    <div class="main-left-content">
        <article class="container-post" id="bottom">
                <div class="article-title">
                    <h1><?php $this->title() ?></h1>
                    <span><?php $this->category('/'); ?></span>
                </div>
                <div class="article-wrapper article-postlist">
                    <?php $this->content('- 阅读剩余部分 -'); ?>
                </div>
        </article>
    </div>
    <div class="main-content">
        <main class="content-bg">
            <!--评论-->
            <div class="container">
                <?php $this->need('comments.php');?>
            </div>
        </main>
        <?php $this->need('Public/Footer.php');?>
    </div>
</div>
<?php $this->need('Footer.php');?>




