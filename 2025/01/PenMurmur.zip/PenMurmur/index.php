<?php
/**
 *  全称 “ PenMurmur ”。“ Pen ” 代表钢笔 是书写的重要工具 象征着文字创作 
 *  “ Murmur ” 意为“低语” “呢喃” 给人一种轻声诉说 温柔倾诉的感觉 
 *  总结：“ 用钢笔轻声低语 分享故事与想法 ” 
 *  “ 环境要求：PHP 7.4 ~ 8.4 ”
 * 
 * <style>p{line-height:2.2;}</style>
 * 
 * @package PenMurmur
 * 
 * @author 林翊
 * 
 * @version 1.2
 * 
 * @link //ouyu.me
 * 
 */
if (!defined('__TYPECHO_ROOT_DIR__')) exit;
$this->need('Public/Include.php');
?>
<div class="main-wrapper">
    <!--侧栏导航-->
    <?php $this->need('Public/Header.php');?>
    <!--主体-->
    <div class="main-left-content">
        <?php if ($this->have()): ?>
        <?php $isFirst = true; // 初始化一个标志变量，用于判断是否是第一篇文章 ?>
        <div class="article-list">
        <?php while ($this->next()): ?>
            <?php if ($isFirst): ?>
                <!-- 第一篇文章的样式 -->
                <article class="article-item first-post">
                    <div class="article-content">
                        <div class="article-image">
                            <img src="https://dailybing.com/api/v1" >
                        </div>
                        <div class="article-content-descr">
                            <div class="descr-left">
                                <h3><?php $this->title() ?></h3>
                                <a href="<?php $this->permalink() ?>" class="mil-link mil-hover-link mil-text-link">前往阅读</a>
                            </div>
                            <div class="descr-right">
                                <p><?php $this->excerpt(140, '...'); ?></p>
                            </div>
                        </div>
                    </div>
                </article>
            <?php else: ?>
                <!-- 其他文章的样式 -->
                <article class="article-item other-post">
                    <div class="article-content">
                        <div class="article-image">
                            <img src="https://dailybing.com/api/v1" >
                        </div>
                        <div class="article-content-descr">
                            <div class="descr-left">
                                <h3><?php $this->title() ?></h3>
                                <a href="<?php $this->permalink() ?>" class="mil-link mil-hover-link mil-text-link">前往阅读</a>
                            </div>
                            <div class="descr-right">
                                <p><?php $this->excerpt(140, '...'); ?></p>
                            </div>
                        </div>
                    </div>
                </article>
            <?php endif; ?>
            <?php $isFirst = false; // 将标志变量设置为false，后续文章不再应用第一篇文章的样式 ?>
        <?php endwhile; ?>
        </div>
        <?php else: ?>
            暂无文章
        <?php endif; ?>
        <div class="bottom-other">
            显示三栏文章排版
        </div>
    </div>
    <div class="main-content">
        <main class="content-bg">
            <!--banner-->
            <div class="header-banner">
                <div class="header-banner-bg">
                    <img src="https://dailybing.com/api/v1" class="banner-bg scale-img fw-banner">
                </div>
            </div>
            <!--内容-->
            <div class="container">
                <?php $this->need('Public/Index.php');?>
            </div>
        </main>
        <?php $this->need('Public/Footer.php');?>
    </div>
</div>
<?php $this->need('Footer.php');?>




