<?php
/**
 * Template Name: Recent Posts
 */
if (!defined('__TYPECHO_ROOT_DIR__')) exit;
$this->need('header.php');
?>

<div class="recent-posts">
    <h2>最新文章</h2>
    <ul>
        <?php $this->widget('Widget_Contents_Post_Recent', 'pageSize=5')->to($posts); ?>
        <?php while ($posts->next()): ?>
            <li>
                <a href="<?php $posts->permalink(); ?>"><?php $posts->title(); ?></a>
            </li>
        <?php endwhile; ?>
    </ul>
</div>

<?php $this->need('footer.php'); ?>