(function ($) {
    $.fn.extend({
        /* 按键盘实现插入内容 */
        shortcuts: function () {
            this.keydown(function (e) {
                var _this = $(this);
                e.stopPropagation();
                if (e.altKey) {
                    switch (e.keyCode) {
                        case 67:
                            _this.insertContent('[code]' + _this.selectionRange() + '[/code]');
                            break;
                    }
                }
            });
        },
        /* 插入内容 */
        insertContent: function (myValue, t) {
            var $t = $(this)[0];
            if (document.selection) {
                this.focus();
                var sel = document.selection.createRange();
                sel.text = myValue;
                this.focus();
                sel.moveStart('character', -l);
                var wee = sel.text.length;
                if (arguments.length == 2) {
                    var l = $t.value.length;
                    sel.moveEnd('character', wee + t);
                    t <= 0 ? sel.moveStart('character', wee - 2 * t - myValue.length) : sel.moveStart('character', wee - t - myValue.length);
                    sel.select();
                }
            } else if ($t.selectionStart || $t.selectionStart == '0') {
                var startPos = $t.selectionStart;
                var endPos = $t.selectionEnd;
                var scrollTop = $t.scrollTop;
                $t.value = $t.value.substring(0, startPos) + myValue + $t.value.substring(endPos, $t.value.length);
                this.focus();
                $t.selectionStart = startPos + myValue.length;
                $t.selectionEnd = startPos + myValue.length;
                $t.scrollTop = scrollTop;
                if (arguments.length == 2) {
                    $t.setSelectionRange(startPos - t, $t.selectionEnd + t);
                    this.focus();
                }
            } else {
                this.value += myValue;
                this.focus();
            }
        },
        /* 选择 */
        selectionRange: function (start, end) {
            var str = '';
            var thisSrc = this[0];
            if (start === undefined) {
                if (/input|textarea/i.test(thisSrc.tagName) && /firefox/i.test(navigator.userAgent)) str = thisSrc.value.substring(thisSrc.selectionStart, thisSrc.selectionEnd);
                else if (document.selection) str = document.selection.createRange().text;
                else str = document.getSelection().toString();
            } else {
                if (!/input|textarea/.test(thisSrc.tagName.toLowerCase())) return false;
                end === undefined && (end = start);
                if (thisSrc.setSelectionRange) {
                    thisSrc.setSelectionRange(start, end);
                    this.focus();
                } else {
                    var range = thisSrc.createTextRange();
                    range.move('character', start);
                    range.moveEnd('character', end - start);
                    range.select();
                }
            }
            if (start === undefined) return str;
            else return this;
        }
    });
})(jQuery);

/* 新按钮 */
$(function() {
    const items = [
        {
            title: '删除线',
            id: 'wmd-html',
            svg: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="20" height="20"><path fill="none" d="M0 0h24v24H0z"/><path d="M17.154 14c.23.516.346 1.09.346 1.72 0 1.342-.524 2.392-1.571 3.147C14.88 19.622 13.433 20 11.586 20c-1.64 0-3.263-.381-4.87-1.144V16.6c1.52.877 3.075 1.316 4.666 1.316 2.551 0 3.83-.732 3.839-2.197a2.21 2.21 0 0 0-.648-1.603l-.12-.117H3v-2h18v2h-3.846zm-4.078-3H7.629a4.086 4.086 0 0 1-.481-.522C6.716 9.92 6.5 9.246 6.5 8.452c0-1.236.466-2.287 1.397-3.153C8.83 4.433 10.271 4 12.222 4c1.471 0 2.879.328 4.222.984v2.152c-1.2-.687-2.515-1.03-3.946-1.03-2.48 0-3.719.782-3.719 2.346 0 .42.218.786.654 1.099.436.313.974.562 1.613.75.62.18 1.297.414 2.03.699z" fill="rgba(153,153,153,1)"/></svg>',
            type: 'wmd-button',
            text: '~~删除线内容~~'
        },
        {
            title: '下划线',
            id: 'wmd-html',
            svg: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="20" height="20"><path fill="none" d="M0 0h24v24H0z"/><path d="M8 3v9a4 4 0 1 0 8 0V3h2v9a6 6 0 1 1-12 0V3h2zM4 20h16v2H4v-2z" fill="rgba(153,153,153,1)"/></svg>',
            type: 'wmd-button',
            text: '<u>下划线内容</u>'
        },
        {
            title: '脚注',
            id: 'wmd-html',
            svg: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="20" height="20"><path d="M11 7V20H9V7H3V5H15V7H11ZM19.5507 6.5803C19.7042 6.43453 19.8 6.22845 19.8 6C19.8 5.55817 19.4418 5.2 19 5.2C18.5582 5.2 18.2 5.55817 18.2 6C18.2 6.07624 18.2107 6.14999 18.2306 6.21983L17.0765 6.54958C17.0267 6.37497 17 6.1906 17 6C17 4.89543 17.8954 4 19 4C20.1046 4 21 4.89543 21 6C21 6.57273 20.7593 7.08923 20.3735 7.45384L18.7441 9H21V10H17V9L19.5507 6.5803V6.5803Z" fill="rgba(153,153,153,1)"></path></svg>',
            type: 'wmd-button',
            text: '\n这是一个脚注[^1]。\n[^1]: 这是一个脚注示例。\n'
        },
        {
            title: '着重色',
            id: 'wmd-emphasis-button',
            svg: '<svg class="icon" width="20" height="20"viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="8710"><path d="M514.56 71.68C265.216 71.68 66.56 270.848 66.56 519.68S265.216 967.68 514.56 967.68c39.936 0 74.752-34.816 74.752-74.752 0-19.968-5.12-34.816-19.456-49.664-9.728-14.848-19.968-30.208-19.968-49.664 0-39.936 34.816-74.752 74.752-74.752h89.6c139.264 0 248.832-109.056 248.832-248.832-1.024-219.136-199.68-398.336-448.512-398.336zM240.64 519.68c-39.936 0-74.752-34.816-74.752-74.752S200.704 370.176 240.64 370.176s74.752 34.816 74.752 74.752-34.816 74.752-74.752 74.752z m148.992-199.168c-39.936 0-74.752-34.816-74.752-74.752s34.816-74.752 74.752-74.752S464.384 205.824 464.384 245.76s-34.816 74.752-74.752 74.752z m249.344 0c-39.936 0-74.752-34.816-74.752-74.752s34.816-74.752 74.752-74.752 74.752 34.816 74.752 74.752c-0.512 39.936-34.816 74.752-74.752 74.752z m148.992 199.168c-39.936 0-74.752-34.816-74.752-74.752s34.816-74.752 74.752-74.752 74.752 34.816 74.752 74.752-34.816 74.752-74.752 74.752z" fill="rgba(153,153,153,1)" p-id="8711"></path></svg>',
            type: 'wmd-button',
            text: '\n'
        },
        {
            title: 'html代码',
            id: 'wmd-html',
            svg: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="20" height="20"><path fill="none" d="M0 0h24v24H0z"/><path d="M12 18.178l-4.62-1.256-.328-3.544h2.27l.158 1.844 2.52.667 2.52-.667.26-2.866H6.96l-.635-6.678h11.35l-.227 2.21H8.822l.204 2.256h8.217l-.624 6.778L12 18.178zM3 2h18l-1.623 18L12 22l-7.377-2L3 2zm2.188 2L6.49 18.434 12 19.928l5.51-1.494L18.812 4H5.188z" fill="rgba(153,153,153,1)"/></svg>',
            type: 'wmd-button',
            text: '\n!!!\n<p align="center">居中</p>\n<p align="right">居右</p>\n<font size="5" color="red">颜色&大小</font>\n!!!\n'
        },
        {
            title: '复选框（空）',
            id: 'wmd-check1',
            svg: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="20" height="20"><path d="M4 3H20C20.5523 3 21 3.44772 21 4V20C21 20.5523 20.5523 21 20 21H4C3.44772 21 3 20.5523 3 20V4C3 3.44772 3.44772 3 4 3ZM5 5V19H19V5H5Z" fill="rgba(153,153,153,1)"></path></svg>',
            type: 'wmd-button',
            text: '\n{ } 复选框\n'
        },
        {
            title: '复选框（选）',
            id: 'wmd-check2',
            svg: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="20" height="20"><path d="M4 3H20C20.5523 3 21 3.44772 21 4V20C21 20.5523 20.5523 21 20 21H4C3.44772 21 3 20.5523 3 20V4C3 3.44772 3.44772 3 4 3ZM5 5V19H19V5H5ZM11.0026 16L6.75999 11.7574L8.17421 10.3431L11.0026 13.1716L16.6595 7.51472L18.0737 8.92893L11.0026 16Z" fill="rgba(153,153,153,1)"></path></svg>',
            type: 'wmd-button',
            text: '\n{x} 复选框\n'
        },
        {
            title: '短代码',
            id: 'wmd-short-code',
            svg: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="20" height="20"><path fill="none" d="M0 0h24v24H0z"/><path d="M24 12l-5.657 5.657-1.414-1.414L21.172 12l-4.243-4.243 1.414-1.414L24 12zM2.828 12l4.243 4.243-1.414 1.414L0 12l5.657-5.657L7.07 7.757 2.828 12zm6.96 9H7.66l6.552-18h2.128L9.788 21z" fill="rgba(153,153,153,1)"/></svg>',
            type: 'wmd-button',
            text: '\`短代码\`'
        },
        {
            title: '长代码',
            id: 'wmd-long-code',
            svg: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="20" height="20"><path fill="none" d="M0 0h24v24H0z"/><path d="M11 12l-7.071 7.071-1.414-1.414L8.172 12 2.515 6.343 3.929 4.93 11 12zm0 7h10v2H11v-2z" fill="rgba(153,153,153,1)"/></svg>',
            type: 'wmd-button',
            text: '\n'
        },
        {
            title: '回复可见',
            id: 'wmd-hide-button',
            svg: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="20" height="20"><path fill="none" d="M0 0h24v24H0z"/><path d="M17.882 19.297A10.949 10.949 0 0 1 12 21c-5.392 0-9.878-3.88-10.819-9a10.982 10.982 0 0 1 3.34-6.066L1.392 2.808l1.415-1.415 19.799 19.8-1.415 1.414-3.31-3.31zM5.935 7.35A8.965 8.965 0 0 0 3.223 12a9.005 9.005 0 0 0 13.201 5.838l-2.028-2.028A4.5 4.5 0 0 1 8.19 9.604L5.935 7.35zm6.979 6.978l-3.242-3.242a2.5 2.5 0 0 0 3.241 3.241zm7.893 2.264l-1.431-1.43A8.935 8.935 0 0 0 20.777 12 9.005 9.005 0 0 0 9.552 5.338L7.974 3.76C9.221 3.27 10.58 3 12 3c5.392 0 9.878 3.88 10.819 9a10.947 10.947 0 0 1-2.012 4.592zm-9.084-9.084a4.5 4.5 0 0 1 4.769 4.769l-4.77-4.769z" fill="rgba(139,139,139,1)"/></svg>',
            type: 'wmd-button',
            text: '\n{article_hide}\n这里的内容回复后才能看见\n{/article_hide}\n'
        },
        {
            title: '插入表格',
            id: 'wmd-table-button',
            svg: '<svg t="1668215446794" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="2736" width="20" height="20"><path d="M182.701 915.991c-40.5 0-74.701-33.539-74.701-74.701V182.71c0-34.822 28.755-74.701 73.206-74.701h660.093c38.579 0 74.701 32.098 74.701 74.701v658.58c0 40.384-30.676 74.701-74.701 74.701H182.701z m478.41-73.826h180.115V667.193H661.111v174.972z m-226.475 0h151.992V667.193H434.636v174.972z m-253.43 0h178.948V667.193H181.206v174.972z m479.905-254.379h180.115V408.164H661.111v179.622z m-226.475 0h151.992V408.164H434.636v179.622z m-253.43 0h178.948V408.164H181.206v179.622z m0-406.808v148.746l660.129 2.225v-150.6l-660.129-0.371z" p-id="2737" fill="#999999"></path></svg>',
            type: 'origin_btn',
            text: '\n| 表头 | 表头 | 表头 |\n| :--: | :--: | :--: |\n| 表格 | 表格 | 表格 |\n| 表格 | 表格 | 表格 |\n| 表格 | 表格 | 表格 |\n'
        },
        {
            title: 'Emoji表情',
            id: 'wmd-emoji',
            svg: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="20" height="20"><path fill="none" d="M0 0h24v24H0z"/><path d="M12 22C6.477 22 2 17.523 2 12S6.477 2 12 2s10 4.477 10 10-4.477 10-10 10zm0-2a8 8 0 1 0 0-16 8 8 0 0 0 0 16zm-5-7h2a3 3 0 0 0 6 0h2a5 5 0 0 1-10 0zm1-2a1.5 1.5 0 1 1 0-3 1.5 1.5 0 0 1 0 3zm8 0a1.5 1.5 0 1 1 0-3 1.5 1.5 0 0 1 0 3z" fill="rgba(153,153,153,1)"/></svg>',
            type: 'origin_btn',
            text: '\nEmoji表情\n'
        },
        {
            title: 'TIP文本框',
            id: 'wmd-tip-button',
            svg: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="20" height="20"><path d="M21 3C21.5523 3 22 3.44772 22 4V20C22 20.5523 21.5523 21 21 21H3C2.44772 21 2 20.5523 2 20V4C2 3.44772 2.44772 3 3 3H21ZM20 5H4V19H20V5ZM8 7V17H6V7H8Z" fill="rgba(153,153,153,1)"></path></svg>',
            type: 'wmd-button',
            text: ''
        },
        {
            title: '提示文本框',
            id: 'wmd-prompt-button',
            svg: '<svg class="icon"  width="20" height="20" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="23550"><path d="M512 512m-512 0a512 512 0 1 0 1024 0 512 512 0 1 0-1024 0Z" fill="rgba(153,153,153,.5)" p-id="23551"></path><path d="M512 814.545455a302.545455 302.545455 0 0 1-213.934545-516.48 302.545455 302.545455 0 1 1 427.86909 427.86909A300.555636 300.555636 0 0 1 512 814.545455z m-124.148364-328.052364a36.072727 36.072727 0 0 0-25.6 61.486545l92.997819 93.730909a29.917091 29.917091 0 0 0 42.46109 0l165.853091-166.74909a29.928727 29.928727 0 0 0-40.226909-44.218182l-127.418182 104.808727a29.905455 29.905455 0 0 1-38.597818-0.488727l-45.905454-39.761455a36.002909 36.002909 0 0 0-23.563637-8.808727z" fill="rgba(153,153,153,1)" p-id="23552"></path></svg>',
            type: 'wmd-button',
            text: ''
        },
        {
            title: '面板',
            id: 'wmd-Panel-button',
            svg: '<svg class="icon"  width="25" height="25" style="fill:rgba(153,153,153,1);" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="18611"><path d="M883.66 852.62H146.42c-43.66 0-79.38-35.72-79.38-79.38V292.01c0-43.66 35.72-79.38 79.38-79.38h737.24c43.66 0 79.38 35.72 79.38 79.38v481.24c0 43.65-35.72 79.37-79.38 79.37z m15.38-129.73V342.36c0-36.15-29.58-65.73-65.73-65.73H196.77c-36.15 0-65.73 29.58-65.73 65.73v380.53c0 36.15 29.58 65.73 65.73 65.73H833.3c36.16 0 65.74-29.58 65.74-65.73zM793.53 540.62H458.76c-17.67 0-32-14.33-32-32s14.33-32 32-32h334.77c17.67 0 32 14.33 32 32 0 17.68-14.32 32-32 32zM284.54 508.62m-48 0a48 48 0 1 0 96 0 48 48 0 1 0-96 0ZM793.53 668.62H458.76c-17.67 0-32-14.33-32-32s14.33-32 32-32h334.77c17.67 0 32 14.33 32 32 0 17.68-14.32 32-32 32zM284.54 636.62m-48 0a48 48 0 1 0 96 0 48 48 0 1 0-96 0ZM104.68 244.62h832v128h-832z" p-id="18612"></path></svg>',
            type: 'wmd-button',
            text: '\n'
        },
        {
            title: '图片',
            id: 'wmd-addimage-button',
            svg: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="20" height="20"><path fill="none" d="M0 0h24v24H0z"/><path d="M4.828 21l-.02.02-.021-.02H2.992A.993.993 0 0 1 2 20.007V3.993A1 1 0 0 1 2.992 3h18.016c.548 0 .992.445.992.993v16.014a1 1 0 0 1-.992.993H4.828zM20 15V5H4v14L14 9l6 6zm0 2.828l-6-6L6.828 19H20v-1.172zM8 11a2 2 0 1 1 0-4 2 2 0 0 1 0 4z" fill="rgba(153,153,153,1)"/></svg>',
            type: 'wmd-button',
            text: '\n![图片描述](图片链接)\n'
        },{
			title: "图集",
			id: "wmd-photos-button",
			svg: '<svg class="icon" width="20" height="20" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="1181"><path d="M896 512A384 384 0 0 0 533.333333 129.066667h-21.333333A384 384 0 0 0 129.066667 490.666667v21.333333A384 384 0 0 0 490.666667 896h21.333333a384 384 0 0 0 384-362.666667v-21.333333z m-85.333333 0v13.013333a128 128 0 0 1-249.813334 23.893334A213.333333 213.333333 0 0 0 721.066667 298.666667 298.666667 298.666667 0 0 1 810.666667 512zM512 213.333333h13.013333a128 128 0 0 1 23.893334 249.813334A213.333333 213.333333 0 0 0 298.666667 302.933333 298.666667 298.666667 0 0 1 512 213.333333zM213.333333 512v-13.013333a128 128 0 0 1 249.813334-23.893334A213.333333 213.333333 0 0 0 302.933333 725.333333 298.666667 298.666667 0 0 1 213.333333 512z m298.666667 298.666667h-13.013333a128 128 0 0 1-23.893334-249.813334A213.333333 213.333333 0 0 0 725.333333 721.066667 298.666667 298.666667 0 0 1 512 810.666667z" p-id="1182" fill="rgba(153,153,153,1)"></path></svg>',
			type: "wmd-button",
			text: "\n{photos}\n![图片描述](图片链接)\n![图片描述](图片链接)\n{/photos}\n"
		},
        {
            title: '音频',
            id: 'wmd-localmusic-button',
            svg: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="20" height="20"><path fill="none" d="M0 0h24v24H0z"/><path d="M20 3v14a4 4 0 1 1-2-3.465V5H9v12a4 4 0 1 1-2-3.465V3h13zM5 19a2 2 0 1 0 0-4 2 2 0 0 0 0 4zm11 0a2 2 0 1 0 0-4 2 2 0 0 0 0 4z" fill="rgba(153,153,153,1)"/></svg>',
            type: 'wmd-button',
            text: ''
        },
        {
            title: '网易云音乐',
            id: 'wmd-webmusic-button',
            svg: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="20" height="20"><path d="M10.4222 11.375C10.1278 12.4026 10.4341 13.4395 11.2058 14.0282C12.267 14.8376 13.7712 14.3289 14.0796 13.0331C14.1599 12.6958 14.1833 12.311 14.1067 11.9767C13.8775 10.9756 13.586 9.98862 13.3147 8.98094C11.9843 9.13543 10.7722 10.1533 10.4222 11.375ZM15.9698 11.0879C16.2427 12.1002 16.2553 13.1053 15.8435 14.0875C14.7148 16.7784 11.1215 17.2286 9.26951 14.9136C7.96829 13.2869 7.99065 10.953 9.32982 9.18031C10.1096 8.14796 11.1339 7.47322 12.3776 7.12595C12.5007 7.09159 12.6241 7.058 12.7566 7.02157C12.6731 6.60736 12.569 6.20612 12.5143 5.79828C12.3375 4.48137 13.026 3.29477 14.2582 2.7574C15.4836 2.22294 16.9661 2.54204 17.7889 3.51738C18.1936 3.99703 18.183 4.59854 17.7631 4.98218C17.3507 5.359 16.7665 5.32761 16.3276 4.89118C16.0809 4.64585 15.8185 4.45112 15.451 4.45569C14.9264 4.46223 14.4642 4.87382 14.5058 5.39329C14.5432 5.86105 14.6785 6.32376 14.8058 6.77892C14.8276 6.85679 15.0218 6.91415 15.1436 6.9321C16.4775 7.12862 17.6476 7.66332 18.6165 8.60769C21.1739 11.1006 21.4772 15.1394 19.2882 18.0482C17.7593 20.0797 15.6785 21.2165 13.1609 21.4567C8.53953 21.8977 4.49683 18.9278 3.46188 14.3992C2.5147 10.2551 4.8397 5.83074 8.79509 4.25032C9.38067 4.01635 9.93787 4.21869 10.1664 4.74827C10.3982 5.28546 10.147 5.83389 9.55552 6.09847C7.18759 7.15787 5.73935 8.9527 5.34076 11.5215C4.80806 14.9546 6.99662 18.2982 10.3416 19.2428C13.0644 20.0117 15.9994 19.0758 17.6494 16.9123C19.2354 14.8328 19.0484 11.8131 17.2221 10.0389C16.7172 9.54838 16.1246 9.21455 15.3988 9.02564C15.5974 9.74151 15.7879 10.4136 15.9698 11.0879Z" fill="rgba(153,153,153,1)"></path></svg>',
            type: 'wmd-button',
            text: '\n{webmusic name="歌曲名" id="网易云音乐ID"}\n'
        },
        {
            title: '视频',
            id: 'wmd-video-button',
            svg: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="20" height="20"><path fill="none" d="M0 0h24v24H0z"/><path d="M2 3.993A1 1 0 0 1 2.992 3h18.016c.548 0 .992.445.992.993v16.014a1 1 0 0 1-.992.993H2.992A.993.993 0 0 1 2 20.007V3.993zM8 5v14h8V5H8zM4 5v2h2V5H4zm14 0v2h2V5h-2zM4 9v2h2V9H4zm14 0v2h2V9h-2zM4 13v2h2v-2H4zm14 0v2h2v-2h-2zM4 17v2h2v-2H4zm14 0v2h2v-2h-2z" fill="rgba(153,153,153,1)"/></svg>',
            type: 'wmd-button',
            text: '\n{video key="这里输入视频链接地址"}\n'
        },
        {
            title: 'bilibili视频',
            id: 'wmd-bili-button',
            svg: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="20" height="20"><path d="M7.17157 2.75725L10.414 5.99936H13.585L16.8284 2.75725C17.219 2.36672 17.8521 2.36672 18.2426 2.75725C18.6332 3.14777 18.6332 3.78094 18.2426 4.17146L16.414 5.99936L18.5 5.99989C20.433 5.99989 22 7.56689 22 9.49989V17.4999C22 19.4329 20.433 20.9999 18.5 20.9999H5.5C3.567 20.9999 2 19.4329 2 17.4999V9.49989C2 7.56689 3.567 5.99989 5.5 5.99989L7.585 5.99936L5.75736 4.17146C5.36684 3.78094 5.36684 3.14777 5.75736 2.75725C6.14788 2.36672 6.78105 2.36672 7.17157 2.75725ZM18.5 7.99989H5.5C4.7203 7.99989 4.07955 8.59478 4.00687 9.35543L4 9.49989V17.4999C4 18.2796 4.59489 18.9203 5.35554 18.993L5.5 18.9999H18.5C19.2797 18.9999 19.9204 18.405 19.9931 17.6444L20 17.4999V9.49989C20 8.67146 19.3284 7.99989 18.5 7.99989ZM8 10.9999C8.55228 10.9999 9 11.4476 9 11.9999V13.9999C9 14.5522 8.55228 14.9999 8 14.9999C7.44772 14.9999 7 14.5522 7 13.9999V11.9999C7 11.4476 7.44772 10.9999 8 10.9999ZM16 10.9999C16.5523 10.9999 17 11.4476 17 11.9999V13.9999C17 14.5522 16.5523 14.9999 16 14.9999C15.4477 14.9999 15 14.5522 15 13.9999V11.9999C15 11.4476 15.4477 10.9999 16 10.9999Z" fill="rgba(153,153,153,1)"></path></svg>',
            type: 'wmd-button',
            text: '\n{bili p="1" key="这里输入B站BV号"}\n'
        }
    ];
    items.forEach(_ => {
        let item = $(`<li class="${_.type}" id="${_.id}" title="${_.title}">${_.svg}</li>`);
        item.on('click', function () {
            if(_.type == 'wmd-button'){
                $('#text').insertContent(_.text);
            }
        });
        $('#wmd-button-row').append(item);
    });
});

/* 隐藏默认的插入按钮 */
$(function() {
    $('#wmd-hide-button').before('<li id="wmd-spacer2" class="wmd-spacer"></li>');
    $('#wmd-bili-button').after('<li class="wmd-spacer" id="wmd-spacer2"></li><button title="发表" style="box-shadow: unset;padding: 0.5rem;vertical-align: middle;line-height: 0.5rem;border: unset;margin: 0.2rem;border-radius: 20%!important;background: unset;" type="submit" class="btn primary" id="btn-submit"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="20" height="20"><path fill="none" d="M0 0h24v24H0z"/><path d="M16.596 1.04l6.347 6.346a.5.5 0 0 1-.277.848l-1.474.23-5.656-5.656.212-1.485a.5.5 0 0 1 .848-.283zM4.595 20.15c3.722-3.331 7.995-4.328 12.643-5.52l.446-4.018-4.297-4.297-4.018.446c-1.192 4.648-2.189 8.92-5.52 12.643L2.454 18.01c2.828-3.3 3.89-6.953 5.303-13.081l6.364-.707 5.657 5.657-.707 6.364c-6.128 1.414-9.782 2.475-13.081 5.303L4.595 20.15zm5.284-6.03a2 2 0 1 1 2.828-2.828A2 2 0 0 1 9.88 14.12z" fill="rgba(153,153,153,1)"/></svg></button><hr id="emojistart" style="border: unset;">');
    var emojiall = "😀 😁 😂 😃 😄 😅 😆 😉 😊 😋 😎 😍 😘 😗 😙 😚 😇 😐 😑 😶 😏 😣 😥 😮 😯 😪 😫 😴 😌 😛 😜 😝 😒 😓 😔 😕 😲 😷 😖 😞 😟 😤 😢 😭 😦 😧 😨 😬 😰 😱 😳 😵 😡 😠";
    var emojiarr = emojiall.split(" ");
    var emoji = "<div class='emojiblock' style='display:none;'>";
        emojiarr.forEach(function(element) {
            emoji += "<span class='editor_emoji'>" + element + "</span>";
        });
    emoji += "</div>";
    $('#emojistart').after(emoji);
});
$(document).on('click', '.editor_emoji',function () {
    var emoji = $(this).text();
    $('#wmd-editarea textarea').insertContent(emoji);
    $('#wmd-editarea textarea').focus();
});

window.onload = function () {
    /* 样式栏 */
    $(document).ready(function(){
        if ($("#custom-field").length >0){
            /* Emoji表情 */
            $(document).on('click', '#wmd-emoji', function() {
                $('.emojiblock').slideToggle();
            });
            // TIP文本框
            $(document).on('click', '#wmd-tip-button', function() {
                // 创建TIP面板的HTML结构
                let panelHtml = `
                    <div id="tipPanel" class="wmd-prompt-dialog">
                        <div class="wmd-prompt-background" style="position: fixed; top: 0; left: 0; right: 0; bottom: 0; background-color: rgba(0, 0, 0, 0.5); z-index: 1000;"></div>
                        <div class="wmd-prompt-dialog-content" style="position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); background-color: white; padding: 20px; border-radius: 5px; z-index: 1001;">
                            <h3 class="typecho-label">插入TIP文本框</h3>
                            <div class="form-group">
                                <label>类型</label>
                                <select class="form-control" id="type">
                                    <option value="yellow">提示橙</option>
                                    <option value="red">警告红</option>
                                    <option value="blue">信息蓝</option>
                                    <option value="green">推荐绿</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>TIP内容</label>
                                <textarea class="form-control" name="tipContent" rows="3" placeholder="请输入TIP内容"></textarea>
                            </div>
                            <div class="form-group">
                                <button type="button" class="btn btn-primary" id="wmd-tip-button_ok">确定</button>
                                <button type="button" class="btn btn-secondary" id="tip_cancel">取消</button>
                            </div>
                        </div>
                    </div>
                `;
                // 将TIP面板添加到页面中
                $('body').append(panelHtml);
            });
            // 确定
            $(document).on('click', '#wmd-tip-button_ok', function() {
                // 获取用户选择的TIP类型和输入的TIP内容
                let tipType = $('#type').val();
                let tipContent = $('textarea[name="tipContent"]').val();
            
                // 验证用户输入是否为空
                if (!tipContent) {
                    alert('请输入TIP内容');
                    return;
                }
            
                // 构建TIP的Markdown代码
                const markdown = `<!-- TIP Start -->\n{tip color="${tipType}" content="${tipContent}"}\n<!-- TIP End -->\n`;
            
                // 将生成的Markdown代码插入到编辑器中
                $('#text').insertContent(markdown); // 假设你有一个名为 #text 的元素来插入内容
            
                // 关闭TIP面板
                $('#tipPanel').remove();
            });
            // 取消
            $(document).on('click', '#tip_cancel', function() {
                // 关闭TIP面板
                $('#tipPanel').remove();
                // 将焦点返回到编辑区域
                $('#wmd-editarea textarea').focus();
            });
            // 着重色
            $(document).on('click', '#wmd-emphasis-button', function() {
                // 创建着重色面板的HTML结构
                let panelHtml = `
                    <div id="emphasisPanel" class="wmd-prompt-dialog">
                        <div class="wmd-prompt-background" style="position: fixed; top: 0; left: 0; right: 0; bottom: 0; background-color: rgba(0, 0, 0, 0.5); z-index: 1000;"></div>
                        <div class="wmd-prompt-dialog-content" style="position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); background-color: white; padding: 20px; border-radius: 5px; z-index: 1001;">
                            <h3 class="typecho-label">插入着重色</h3>
                            <div class="form-group">
                                <label>颜色代码</label>
                                <input type="text" class="form-control" name="color" placeholder="请输入颜色代码（如 #FF5733）" autocomplete="off">
                            </div>
                            <div class="form-group">
                                <label>着重色内容</label>
                                <textarea class="form-control" name="emphasisContent" placeholder="请输入着重色内容" rows="3"></textarea>
                            </div>
                            <div class="form-group">
                                <button type="button" class="btn btn-primary" id="wmd-emphasis-button_ok">确定</button>
                                <button type="button" class="btn btn-secondary" id="emphasis_cancel">取消</button>
                            </div>
                        </div>
                    </div>
                `;
                // 将着重色面板添加到页面中
                $('body').append(panelHtml);
            });
            // 确定
            $(document).on('click', '#wmd-emphasis-button_ok', function() {
                // 获取用户输入的着重色信息
                let color = $('input[name="color"]').val();
                let emphasisContent = $('textarea[name="emphasisContent"]').val();
            
                // 验证用户输入是否为空
                if (!emphasisContent) {
                    alert('请输入着重色内容');
                    return;
                }
            
                // 构建着重色的Markdown代码
                const markdown = `<!-- Emphasis Start -->\n{mark color="${color}" content="${emphasisContent}"}\n<!-- Emphasis End -->\n`;
            
                // 将生成的Markdown代码插入到编辑器中
                $('#text').insertContent(markdown); // 假设你有一个名为 #text 的元素来插入内容
            
                // 关闭着重色面板
                $('#emphasisPanel').remove();
            });
            // 取消
            $(document).on('click', '#emphasis_cancel', function() {
                // 关闭着重色面板
                $('#emphasisPanel').remove();
                // 将焦点返回到编辑区域
                $('#wmd-editarea textarea').focus();
            });
            // 本地音乐
            $(document).on('click', '#wmd-localmusic-button', function() {
                // 创建音乐面板的HTML结构
                let panelHtml = `
                    <div id="localmusicPanel" class="wmd-prompt-dialog">
                        <div class="wmd-prompt-background" style="position: fixed; top: 0; left: 0; right: 0; bottom: 0; background-color: rgba(0, 0, 0, 0.5); z-index: 1000;"></div>
                        <div class="wmd-prompt-dialog-content" style="position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); background-color: white; padding: 20px; border-radius: 5px; z-index: 1001;">
                            <h3 class="typecho-label">插入本地音乐</h3>
                            <div class="form-group">
                                <label>音乐名字</label>
                                <input type="text" class="form-control" name="name" placeholder="请输入音乐名字" autocomplete="off">
                            </div>
                            <div class="form-group">
                                <label>歌手名字</label>
                                <input type="text" class="form-control" name="author" placeholder="请输入歌手名字" autocomplete="off">
                            </div>
                            <div class="form-group">
                                <label>音乐地址</label>
                                <input type="text" class="form-control" name="links" placeholder="请输入音乐地址" autocomplete="off">
                            </div>
                            <div class="form-group">
                                <label>音乐封面</label>
                                <input type="text" class="form-control" name="cover" placeholder="请输入音乐封面地址" autocomplete="off">
                            </div>
                            <div class="form-group">
                                <button type="button" class="btn btn-primary" id="wmd-localmusic-button_ok">确定</button>
                                <button type="button" class="btn btn-secondary" id="localmusic_cancel">取消</button>
                            </div>
                        </div>
                    </div>
                `;
                // 将音乐面板添加到页面中
                $('body').append(panelHtml);
            });
            // 确定
            $(document).on('click', '#wmd-localmusic-button_ok', function() {
                // 获取用户输入的音乐信息
                let musicName = $('input[name="name"]').val();
                let musicAuthor = $('input[name="author"]').val();
                let musicLinks = $('input[name="links"]').val();
                let musicCover = $('input[name="cover"]').val();
            
                // 验证用户输入是否为空
                if (!musicName || !musicAuthor || !musicLinks || !musicCover) {
                    alert('请填写完整的音乐信息');
                    return;
                }
            
                // 构建音乐的Markdown代码
                const markdown = `\n<!-- Music -->\n{music musicCover="${musicCover}" musicName="${musicName}" musicAuthor="${musicAuthor}" musicLinks="${musicLinks}"}\n<!-- Music End -->\n`;
            
                // 将生成的Markdown代码插入到编辑器中
                $('#text').insertContent(markdown); // 假设你有一个名为 #text 的元素来插入内容
            
                // 关闭音乐面板
                $('#localmusicPanel').remove();
            });
            // 取消
            $(document).on('click', '#localmusic_cancel', function() {
                // 关闭音乐面板
                $('#localmusicPanel').remove();
            });
            // 面板
            $(document).on('click', '#wmd-Panel-button', function() {
                let panelHtml = `
                    <div id="PanelPanel" class="pandastudio-panel">
                        <div class="wmd-prompt-background" style="position: fixed; top: 0; left: 0; right: 0; bottom: 0; background-color: rgba(0, 0, 0, 0.5); z-index: 1000;"></div>
                        <div class="wmd-prompt-dialog-content" style="position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); background-color: white; padding: 20px; border-radius: 5px; z-index: 1001;">
                            <div class="pandastudio-panel-header">
                                <h3 class="typecho-label">插入面板</h3>
                            </div>
                            <div class="pandastudio-panel-body">
                                <div class="form-group">
                                    <label>面板颜色 (RGB格式，空格隔开。如框里)</label>
                                    <input type="text" class="form-control" name="color" placeholder="例如: 103 194 58" value="" autocomplete="off">
                                </div>
                                <div class="form-group">
                                    <label>面板标题</label>
                                    <input type="text" class="form-control" name="title" placeholder="请输入面板标题" autocomplete="off">
                                </div>
                                <div class="form-group">
                                    <label>面板内容</label>
                                    <textarea class="form-control" name="content" rows="3" placeholder="请输入面板内容"></textarea>
                                </div>
                            </div>
                            <div class="pandastudio-panel-footer">
                                <button type="button" class="btn btn-primary" id="wmd-Panel-button_ok">确定</button>
                                <button type="button" class="btn btn-secondary" id="prompt_cancel">取消</button>
                            </div>
                        </div>
                    </div>
                `;
                // 将面板添加到页面中
                $('body').append(panelHtml);
            });
            // 确定
            $(document).on('click', '#wmd-Panel-button_ok', function() {
                // 获取用户输入的面板信息
                let panelColor = $('input[name="color"]').val();
                let panelTitle = $('input[name="title"]').val();
                let panelContent = $('textarea[name="content"]').val();
            
                // 验证用户输入是否为空
                if (!panelContent) {
                    alert('请输入面板内容');
                    return;
                }
            
                // 构建面板的Markdown代码
                const markdown = `<!-- Panel Start -->\n{panel color="${panelColor}" title="${panelTitle}"}${panelContent}{/panel}\n<!-- Panel End -->\n`;
            
                // 将生成的Markdown代码插入到编辑器中
                $('#text').insertContent(markdown); // 假设你有一个名为 #text 的元素来插入内容
            
                // 关闭面板
                $('#PanelPanel').remove();
            });
            // 取消
            $(document).on('click', '#prompt_cancel', function() {
                // 关闭面板
                $('#PanelPanel').remove();
                // 将焦点返回到编辑区域
                $('#wmd-editarea textarea').focus();
            });
            // 提示框
            $(document).on('click', '#wmd-prompt-button', function() {
                // 创建提示框面板的HTML结构
                let panelHtml = `
                    <div id="promptPanel" class="wmd-prompt-dialog">
                        <div class="wmd-prompt-background" style="position: fixed; top: 0; left: 0; right: 0; bottom: 0; background-color: rgba(0, 0, 0, 0.5); z-index: 1000;"></div>
                        <div class="wmd-prompt-dialog-content" style="position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); background-color: white; padding: 20px; border-radius: 5px; z-index: 1001;">
                            <h3 class="typecho-label">插入提示框</h3>
                            <div class="form-group">
                                <label>类型</label>
                                <select class="form-control" id="type">
                                    <option value="yellow">提示橙</option>
                                    <option value="red">警告红</option>
                                    <option value="blue">信息蓝</option>
                                    <option value="green">推荐绿</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>提示内容</label>
                                <textarea class="form-control" name="promptContent" rows="3" placeholder="请输入提示内容"></textarea>
                            </div>
                            <div class="form-group">
                                <button type="button" class="btn btn-primary" id="wmd-prompt-button_ok">确定</button>
                                <button type="button" class="btn btn-secondary" id="prompt_cancel">取消</button>
                            </div>
                        </div>
                    </div>
                `;
                // 将提示框面板添加到页面中
                $('body').append(panelHtml);
            });
            // 确定
            $(document).on('click', '#wmd-prompt-button_ok', function() {
                // 获取用户选择的提示类型和输入的提示内容
                let promptType = $('#type').val();
                let promptContent = $('textarea[name="promptContent"]').val();
            
                // 验证用户输入是否为空
                if (!promptContent) {
                    alert('请输入提示内容');
                    return;
                }
            
                // 构建提示框的Markdown代码
                const markdown = `<!-- Prompt -->\n{prompt color="${promptType}"}${promptContent}{/prompt}\n<!-- Prompt End -->\n`;
            
                // 将生成的Markdown代码插入到编辑器中
                $('#text').insertContent(markdown); // 假设你有一个名为 #text 的元素来插入内容
            
                // 关闭提示框面板
                $('#promptPanel').remove();
            });
            // 取消
            $(document).on('click', '#prompt_cancel', function() {
                // 关闭提示框面板
                $('#promptPanel').remove();
                // 将焦点返回到编辑区域
                $('#wmd-editarea textarea').focus();
            });
            // 代码
            $(document).on('click', '#wmd-long-code', function() {
                // 创建代码面板的HTML结构
                let panelHtml = `
                    <div id="longCodePanel" class="wmd-prompt-dialog">
                        <div class="wmd-prompt-background" style="position: fixed; top: 0; left: 0; right: 0; bottom: 0; background-color: rgba(0, 0, 0, 0.5); z-index: 1000;"></div>
                        <div class="wmd-prompt-dialog-content" style="position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); background-color: white; padding: 20px; border-radius: 5px; z-index: 1001;">
                            <h3 class="typecho-label">插入长代码</h3>
                            <div class="form-group">
                                <label>代码类型（js/css/html）</label>
                                <input type="text" class="form-control" name="codeType" placeholder="请输入代码类型" autocomplete="off">
                            </div>
                            <div class="form-group">
                                <label>代码内容</label>
                                <textarea class="form-control" name="codeContent" rows="3" placeholder="请输入代码内容"></textarea>
                            </div>
                            <div class="form-group">
                                <button type="button" class="btn btn-primary" id="wmd-long-code_ok">确定</button>
                                <button type="button" class="btn btn-secondary" id="long_code_cancel">取消</button>
                            </div>
                        </div>
                    </div>
                `;
                // 将代码面板添加到页面中
                $('body').append(panelHtml);
            });
            // 确定
            $(document).on('click', '#wmd-long-code_ok', function() {
                // 获取用户输入的代码类型和代码内容
                let codeType = $('input[name="codeType"]').val();
                let codeContent = $('textarea[name="codeContent"]').val();
            
                // 验证用户输入是否为空
                if (!codeType || !codeContent) {
                    alert('请输入代码类型和代码内容');
                    return;
                }
            
                // 构建代码的Markdown代码
                const markdown = `\n<!-- Code -->\n\`\`\`${codeType}\n${codeContent}\n\`\`\`\n<!-- Code End -->\n`;
            
                // 将生成的Markdown代码插入到编辑器中
                $('#text').insertContent(markdown); // 假设你有一个名为 #text 的元素来插入内容
            
                // 关闭代码面板
                $('#longCodePanel').remove();
            });
            // 取消
            $(document).on('click', '#long_code_cancel', function() {
                // 关闭代码面板
                $('#longCodePanel').remove();
                // 将焦点返回到编辑区域
                $('#wmd-editarea textarea').focus();
            });
            /* 插入表格 */
            $(document).on('click', '#wmd-table-button', function() {
                // 创建表格面板的HTML结构
                let panelHtml = `
                    <div id="tablePanel" class="wmd-prompt-dialog">
                        <div class="wmd-prompt-background" style="position: fixed; top: 0; left: 0; right: 0; bottom: 0; background-color: rgba(0, 0, 0, 0.5); z-index: 1000;"></div>
                        <div class="wmd-prompt-dialog-content" style="position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); background-color: white; padding: 20px; border-radius: 5px; z-index: 1001;">
                            <h3 class="typecho-label">插入表格</h3>
                            <div class="form-group">
                                <label>表格行</label>
                                <input type="number" class="form-control" name="rows" value="3" autocomplete="off">
                            </div>
                            <div class="form-group">
                                <label>表格列</label>
                                <input type="number" class="form-control" name="columns" value="3" autocomplete="off">
                            </div>
                            <div class="form-group">
                                <button type="button" class="btn btn-primary" id="wmd-table-button_ok">确定</button>
                                <button type="button" class="btn btn-secondary" id="table_cancel">取消</button>
                            </div>
                        </div>
                    </div>
                `;
                // 将表格面板添加到页面中
                $('body').append(panelHtml);
            });
            
            $(document).on('click', '#wmd-table-button_ok', function() {
                // 获取用户输入的表格行数和列数
                let rows = parseInt($('input[name="rows"]').val());
                let columns = parseInt($('input[name="columns"]').val());
            
                // 验证输入是否为有效数字
                if (isNaN(rows) || rows < 1) rows = 3;
                if (isNaN(columns) || columns < 1) columns = 3;
            
                // 构建表格的Markdown代码
                let tableMarkdown = '';
                // 表头
                for (let i = 0; i < columns; i++) {
                    tableMarkdown += '| 表头 ';
                }
                tableMarkdown += '|\n';
                // 分隔线
                for (let i = 0; i < columns; i++) {
                    tableMarkdown += '| :--: ';
                }
                tableMarkdown += '|\n';
                // 表格内容
                for (let i = 0; i < rows; i++) {
                    for (let j = 0; j < columns; j++) {
                        tableMarkdown += '| 单元格 ';
                    }
                    tableMarkdown += '|\n';
                }
            
                // 将生成的Markdown代码插入到编辑器中
                $('#text').insertContent(tableMarkdown); // 假设你有一个名为 #text 的元素来插入内容
            
                // 关闭表格面板
                $('#tablePanel').remove();
            });
            
            $(document).on('click', '#table_cancel', function() {
                // 关闭表格面板
                $('#tablePanel').remove();
                // 将焦点返回到编辑区域
                $('#wmd-editarea textarea').focus();
            });
        }
    });
};
