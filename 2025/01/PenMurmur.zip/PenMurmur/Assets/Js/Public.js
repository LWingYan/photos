// 速读
function popup_snapshot() {
    // 检查遮罩层和弹窗容器是否已经存在
    if ($('#overlay').length === 0 && $('#snapshot-container').length === 0) {
        // 动态创建遮罩层和弹窗容器
        var overlay = $('<div id="overlay"></div>');
        var snapshotContainer = $('<div id="snapshot-container" class="fixed"></div>');

        // 创建包裹内容的 div
        var snapshotItem = $('<div class="snapshot-item article-post"></div>');

        var contentContainer = $('<div id="result-summary" class="article-wrapper formatted-content article-postlist"></div>');
        var closeButton = $('<button id="close-btn"><svg class="icon" style="width: 1.5em;height: 1.5em;vertical-align: middle;fill: currentColor;overflow: hidden;" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="3880"><path d="M645.12 201.728v64.1024c103.0144 49.6128 174.08 154.9824 174.08 276.9408 0 169.6768-137.5232 307.2-307.2 307.2s-307.2-137.5232-307.2-307.2c0-121.9584 71.0656-227.328 174.08-276.9408V201.728C242.5344 254.976 145.92 387.5328 145.92 542.72c0 202.1888 163.8912 366.08 366.08 366.08s366.08-163.8912 366.08-366.08c0-155.1872-96.6144-287.744-232.96-340.992z" fill="rgb(var(--DarkA) / var(--bgA-opacity))" p-id="3881"></path><path d="M552.5504 732.16H476.5696c-8.704 0-15.7696-7.0656-15.7696-15.7696V159.1296c0-8.704 7.0656-15.7696 15.7696-15.7696h75.9808c8.704 0 15.7696 7.0656 15.7696 15.7696v557.2608c0 8.704-7.0656 15.7696-15.7696 15.7696z" fill="rgb(var(--Theme) / var(--bgB-opacity))" p-id="3882"></path></svg><span>关闭</span></button>');
        var linksButton = $('<a href="" id="links-btn"><button><svg class="icon" style="width: 1.5em;height: 1.5em;vertical-align: middle;fill: currentColor;overflow: hidden;" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="16687"><path d="M174.253 801.632c-61.213 0-109.621-52.435-109.621-115.746 0-62.678 47.445-114.696 107.788-115.73l1.833-0.016h340.276v72H174.253c-20.106 0-37.621 18.971-37.621 43.746 0 24.527 17.166 43.366 37.019 43.74l0.602 0.006h677.543l-0.001 0.006 1.061 0.01c60.241 1.023 107.792 52.516 107.792 114.746s-47.55 113.722-107.792 114.746l-1.83 0.015H362.155v-72h488.873c20.214 0 37.62-18.622 37.62-42.761 0-23.898-17.06-42.389-37.015-42.756l-0.605-0.006H174.253z" fill="rgb(var(--Theme) / var(--bgB-opacity))" p-id="16688"></path><path d="M948.572 146.356L807.453 61.563c-17.516-10.525-40.247-4.857-50.772 12.659L544.98 426.554a37 37 0 0 0-4.486 26.706l24.985 118.246 0.251 1.105c0.097 0.405 0.182 0.715 0.395 1.488 5.656 19.636 26.16 30.969 45.796 25.312l116.135-33.453a37 37 0 0 0 21.473-16.498l211.703-352.332c10.525-17.516 4.857-40.247-12.659-50.772z m-67.084 43.69L694.9 500.58l-66.756 19.23-14.36-67.97L800.37 141.305l81.117 48.74z" fill="rgb(var(--DarkA) / var(--bgA-opacity))" p-id="16689"></path></svg><span>评论</span></button></a>');

        // 创建一个包裹关闭按钮和链接按钮的 div
        var buttonsContainer = $('<div class="buttons-container"></div>');

        // 将按钮添加到按钮容器中
        buttonsContainer.append(closeButton);
        buttonsContainer.append(linksButton);

        // 将内容容器放入包裹的 div 中
        snapshotItem.append(contentContainer);

        // 将包裹的 div 和按钮容器添加到弹窗容器中
        snapshotContainer.append(snapshotItem);
        snapshotContainer.append(buttonsContainer); // 将按钮容器添加到弹窗容器中

        // 将遮罩层和弹窗容器添加到页面中
        $('body').append(overlay);
        $('body').append(snapshotContainer); // 将弹窗容器直接添加到 body 中
    } else {
        // 获取已存在的元素
        var overlay = $('#overlay');
        var snapshotContainer = $('#snapshot-container');
        var contentContainer = $('#result-summary');
        var closeButton = $('#close-btn');
        var linksButton = $('#links-btn');
    }

    // 默认隐藏遮罩层和弹窗容器
    overlay.hide();
    snapshotContainer.hide();

    // 检查视口宽度
    if ($(window).width() >= 768) {
        // 视口宽度大于等于 768 像素时，绑定点击事件
        $('.popup-link').click(function(event) {
            event.preventDefault(); // 阻止链接的默认跳转行为

            var url = $(this).attr('href'); // 获取链接的URL
            linksButton.attr('href', url); // 将链接的 href 设置为跳转链接的 href

            $.ajax({
                url: url,
                type: 'GET',
                success: function(data) {
                    // 使用 jQuery 解析返回的 HTML 内容
                    var $html = $(data);
                    var content = $html.find('.formatted-content').html(); // 获取类名为 .formatted-content 的内容

                    contentContainer.html(content); // 将内容放入内容容器中
                    overlay.fadeIn(300); // 平滑显示遮罩层
                    snapshotContainer.fadeIn(300); // 平滑显示弹窗容器
                },
                error: function() {
                    console.error('Error fetching the content');
                }
            });
        });

        // 关闭按钮的点击事件
        closeButton.click(function() {
            overlay.fadeOut(300); // 平滑隐藏遮罩层
            snapshotContainer.fadeOut(300); // 平滑隐藏弹窗容器
        });
    } else {
        console.log('弹窗仅在视口宽度大于等于 768px 时显示');
    }
}
// 友链申请
function submitLinkForm() {
    // 绑定表单的提交事件
    $('.xm_link form').on('submit', function(e) {
        e.preventDefault(); // 阻止表单的默认提交行为

        // 显示加载提示
        Qmsg.loading('正在提交...');

        // 获取表单数据
        var formData = $(this).serialize(); // 序列化表单数据

        // 发送 AJAX 请求
        $.ajax({
            type: 'POST', // 请求类型
            url: $(this).attr('action'), // 请求的 URL，从表单的 action 属性获取
            data: formData, // 发送的数据
            success: function(response) {
                // 请求成功后的回调函数
                 Qmsg.closeAll();
                 Qmsg.success('友链申请成功');
                // 可以在这里更新页面或显示提交成功的消息
                // 重置表单
                $('form')[0].reset();
            },
            error: function(xhr, status, error) {
                // 请求失败后的回调函数
               Qmsg.closeAll();
               Qmsg.error('友链申请失败：' + error);
                // 可以在这里显示错误信息
            }
        });
    });
}
// 导航
function menuActivator() {
$('.category_menu').each(function() {
    // 检查是否存在.category-group子元素
    var $dropdownMenu = $(this).find('.category-group');
    if ($dropdownMenu.length) {
        // 给.dropdown-toggle添加点击事件
        $(this).find('.dropdown-toggle').on('click', function(e) {
            // 阻止默认事件和冒泡
            e.preventDefault();
            // 切换.category-group的显示状态
            $dropdownMenu.slideToggle();
        });
    }
});
}