document.addEventListener("DOMContentLoaded", () => {
    // 初始化滚动动画
    initScrollAnimations();
});

function initScrollAnimations() {
    // 获取所有需要监听的元素
    const items = document.querySelectorAll('.article-item');

    // 创建 IntersectionObserver 实例
    const observer = new IntersectionObserver((entries) => {
        entries.forEach((entry) => {
            if (entry.isIntersecting) {
                // 如果元素进入视口，修改 style 属性
                entry.target.style.opacity = 1;
                entry.target.style.pointerEvents = 'auto';
                entry.target.style.transform = 'translateY(0)';
                entry.target.classList.add('visible'); // 添加 visible 类以保持状态
            } else {
                // 如果元素离开视口，判断是向上滑动还是向下滑动
                const rect = entry.target.getBoundingClientRect();
                if (rect.bottom < 0) {
                    // 元素离开视口上方（被滑动过去），保持显示状态
                    entry.target.style.opacity = 1;
                    entry.target.style.pointerEvents = 'auto';
                    entry.target.style.transform = 'translateY(0)';
                    entry.target.classList.add('visible');
                } else {
                    // 元素离开视口下方，恢复初始状态
                    entry.target.style.opacity = 0;
                    entry.target.style.pointerEvents = 'none';
                    entry.target.style.transform = 'translateY(20px)';
                    entry.target.classList.remove('visible');
                }
            }
        });
    }, {
        root: null, // 使用浏览器视口作为参考
        rootMargin: '-20px 0px 0px', // 在视口外20px时触发，仅对上方生效
        threshold: 0 // 元素只要稍微进入视口就触发
    });

    // 开始观察每个元素
    items.forEach(item => observer.observe(item));
}
// 为指定选择器的所有元素添加类名，用于初始化动画
function FadeSelects(selector) {
    // 获取所有匹配选择器的元素
    const elements = document.querySelectorAll(selector);
    // 遍历这些元素，并为每个元素添加 'fade-before' 类
    elements.forEach(element => {
        element.classList.add('fade-before');
    });
};

// 处理动画效果，使得元素在滚动到视口时添加动画类
function FadeAnimate() {
    // 获取所有已经添加了 'fade-before' 类的元素
    const items = document.querySelectorAll('.fade-before');
    // 定义一个函数，用于在元素滚动到视口时添加动画效果
    const animateOnScroll = (elements, delay) => {
        // 创建一个IntersectionObserver实例，用于监听元素是否进入视口
        const observer = new IntersectionObserver((entries, observer) => {
            entries.forEach((entry, index) => {
                // 如果元素进入视口
                if (entry.isIntersecting) {
                    // 设置一个延迟，然后为元素添加 'fade-after' 类，触发动画
                    setTimeout(() => {entry.target.classList.add('fade-after');}, index * delay);
                    // 停止观察当前元素
                    observer.unobserve(entry.target);
                }
            });
        });
        // 遍历所有元素，并开始观察它们
        elements.forEach((element) => {
            observer.observe(element);
        });
    };
    // 调用animateOnScroll函数，为元素设置150毫秒的延迟
    animateOnScroll(items, 150);
};

// 处理动画的延迟效果，使得子元素在父元素动画完成后依次延迟显示
function animateDelayed(parentSelector, childSelector, delayFirstTime, delayChildTime) {
    // 获取所有匹配父选择器的元素
    const parents = document.querySelectorAll(parentSelector);
    // 遍历这些父元素
    parents.forEach((parent, index) => {
        // 获取每个父元素下匹配子选择器的子元素
        const children = parent.querySelectorAll(childSelector);
        // 遍历这些子元素，并为每个子元素设置动画延迟
        children.forEach((child, childIndex) => {
            // 计算总延迟时间，包括初始延迟和每个子元素的额外延迟
            child.style.animationDelay = `${delayFirstTime + childIndex * delayChildTime}s`;
        });
    });
};
$(document).ready(function() {
    // 点击 .bottom-other 时给 <body> 添加 'closed' 类名
    $('.bottom-other').click(function() {
        $('body').addClass('closed');
    });
});
